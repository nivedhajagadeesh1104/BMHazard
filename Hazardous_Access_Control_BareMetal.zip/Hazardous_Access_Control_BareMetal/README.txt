HAZARDOUS ACCESS CONTROL SYSTEM - BARE METAL
STM32 NUCLEO-F446RE

Pin connections:

IR Sensor OUT  -> PB0
White LED      -> PA1
Red LED        -> PA6
Green LED      -> PB5
Buzzer         -> PB10

4x4 Keypad:
R1 -> PC0
R2 -> PC1
R3 -> PC2
R4 -> PC3
C1 -> PC4
C2 -> PC5
C3 -> PC6
C4 -> PC7

Password: 1234
Clear: *
Submit: #
Maximum attempts: 3
Lockout: 10 seconds

IMPORTANT:
This folder contains the application and bare-metal peripheral driver source files.
The STM32F446RE CMSIS device header (stm32f446xx.h), startup file, linker script,
and system project files must be supplied by your STM32CubeIDE/CMSIS project.
The code assumes the MCU is running from the default 16 MHz HSI clock for the
SysTick millisecond delay.
